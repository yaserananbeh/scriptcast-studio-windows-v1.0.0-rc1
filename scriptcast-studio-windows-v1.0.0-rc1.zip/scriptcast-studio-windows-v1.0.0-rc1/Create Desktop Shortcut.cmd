@echo off
setlocal
set "TARGET=%~dp0Launch ScriptCast Studio.cmd"
set "LINK=%USERPROFILE%\Desktop\ScriptCast Studio.lnk"
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut('%LINK%'); $s.TargetPath='%TARGET%'; $s.WorkingDirectory='%~dp0'; $s.Description='ScriptCast Studio - local script to audio and video'; $s.Save()"
echo Desktop shortcut created.
pause
