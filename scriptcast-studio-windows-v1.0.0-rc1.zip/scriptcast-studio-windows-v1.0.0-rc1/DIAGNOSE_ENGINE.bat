@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ScriptCast Studio - engine diagnosis
echo ====================================
echo.
call "%~dp0scriptcast_env.bat"
echo Detected engine root:
echo   %SCRIPTCAST_ENGINE_ROOT%
echo Detected Python:
echo   %PY%
echo Workspace:
echo   %SCRIPTCAST_WORKSPACE%
echo.
if not defined PY goto missing
if not exist "%PY%" goto missing

echo [1/4] Python executable...
"%PY%" -c "import sys; print(sys.executable); print(sys.version)" || goto fail

echo.
echo [2/4] Kokoro...
"%PY%" -c "from kokoro import KPipeline; print('Kokoro import OK')" || goto fail

echo.
echo [3/4] Media dependencies...
"%PY%" -c "import soundfile, numpy, lameenc, PIL, imageio_ffmpeg; print('Media dependency imports OK'); print('FFmpeg:', imageio_ffmpeg.get_ffmpeg_exe())" || goto fail

echo.
echo [4/4] Voice synthesis smoke test...
"%PY%" "%~dp0engine_smoke_test.py" --engine-root "%SCRIPTCAST_ENGINE_ROOT%" || goto fail

echo.
echo ALL CHECKS PASSED.
echo ScriptCast is ready. No reinstall is required.
echo.
pause
exit /b 0

:missing
echo ERROR: No usable ScriptCast engine was found.
echo Run FIRST_RUN_SETUP.cmd.
echo.
pause
exit /b 1

:fail
echo.
echo ERROR: One of the checks failed.
echo Run REPAIR_ENGINE.cmd, or copy the error shown above for troubleshooting.
echo.
pause
exit /b 1
