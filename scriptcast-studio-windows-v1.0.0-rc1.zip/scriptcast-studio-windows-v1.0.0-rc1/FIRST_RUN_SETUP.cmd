@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ScriptCast Studio - First Run Setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0FIRST_RUN_SETUP.ps1"
exit /b %errorlevel%
