$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EngineCfg = Join-Path $AppDir 'engine_location.txt'
$WorkspaceCfg = Join-Path $AppDir 'workspace_location.txt'
$Requirements = Join-Path $AppDir 'engine_requirements.txt'
$SmokeTest = Join-Path $AppDir 'engine_smoke_test.py'
$AppDrive = [IO.Path]::GetPathRoot($AppDir).TrimEnd('\')
if (-not $AppDrive) { $AppDrive = 'C:' }

function Info($text, $title='ScriptCast Studio') {
    [System.Windows.Forms.MessageBox]::Show($text, $title, 'OK', 'Information') | Out-Null
}
function WarnYesNo($text, $title='ScriptCast Studio') {
    return [System.Windows.Forms.MessageBox]::Show($text, $title, 'YesNo', 'Warning') -eq 'Yes'
}
function ErrorBox($text) {
    [System.Windows.Forms.MessageBox]::Show($text, 'ScriptCast Studio setup', 'OK', 'Error') | Out-Null
}
function Test-Engine([string]$Root) {
    if ([string]::IsNullOrWhiteSpace($Root)) { return $false }
    $Py = Join-Path $Root 'venv\Scripts\python.exe'
    if (-not (Test-Path $Py)) { return $false }
    try {
        & $Py -c "import kokoro, soundfile, numpy, lameenc, PIL, imageio_ffmpeg" 2>$null | Out-Null
        return $LASTEXITCODE -eq 0
    } catch { return $false }
}
function Choose-Parent([string]$Description, [string]$Initial) {
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $Description
    $dlg.ShowNewFolderButton = $true
    if ($Initial -and (Test-Path $Initial)) { $dlg.SelectedPath = $Initial }
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.SelectedPath }
    return $null
}
function Set-EngineEnvironment([string]$Root) {
    $env:HF_HOME = Join-Path $Root 'hf'
    $env:HUGGINGFACE_HUB_CACHE = Join-Path $env:HF_HOME 'hub'
    $env:PIP_CACHE_DIR = Join-Path $Root 'pip-cache'
    $env:TORCH_HOME = Join-Path $Root 'torch'
    $env:XDG_CACHE_HOME = Join-Path $Root 'xdg-cache'
    $env:TEMP = Join-Path $Root 'temp'
    $env:TMP = $env:TEMP
    New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
}
function Find-Python312 {
    try {
        $found = (& py -3.12 -c "import sys; print(sys.executable)" 2>$null | Select-Object -Last 1)
        if ($LASTEXITCODE -eq 0 -and $found -and (Test-Path ($found.Trim()))) { return $found.Trim() }
    } catch {}
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
        (Join-Path $env:ProgramFiles 'Python312\python.exe')
    )
    foreach($candidate in $candidates){ if($candidate -and (Test-Path $candidate)){ return $candidate } }
    return $null
}
function Run-External([string]$File, [string[]]$ArgList, [string]$Label) {
    Write-Host ""
    Write-Host "== $Label ==" -ForegroundColor Cyan
    & $File @ArgList
    if ($LASTEXITCODE -ne 0) { throw "$Label failed with exit code $LASTEXITCODE." }
}

try {
    Write-Host 'ScriptCast Studio - First Run Setup' -ForegroundColor Cyan
    Write-Host '====================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host 'This wizard prepares the free local Kokoro speech engine.'
    Write-Host 'No API key or paid account is required.'
    Write-Host ''

    $Candidates = @()
    if (Test-Path $EngineCfg) {
        $c = (Get-Content $EngineCfg -ErrorAction SilentlyContinue | Select-Object -First 1).Trim()
        if ($c) { $Candidates += $c }
    }
    $Candidates += (Join-Path $AppDrive 'ScriptCastEngine')
    if (Test-Path 'D:\PrepLabMediaStudio') { $Candidates += 'D:\PrepLabMediaStudio' }
    $Candidates += (Join-Path $AppDrive 'PrepLabMediaStudio')
    if ($env:LOCALAPPDATA) { $Candidates += (Join-Path $env:LOCALAPPDATA 'PrepLabMediaStudio') }

    $Existing = $Candidates | Select-Object -Unique | Where-Object { Test-Engine $_ } | Select-Object -First 1
    if ($Existing) {
        $reuse = WarnYesNo("A compatible local Kokoro engine is already installed:`n`n$Existing`n`nReuse it? This avoids downloading and installing another copy.", 'Existing engine found')
        if ($reuse) {
            Set-Content -Path $EngineCfg -Value $Existing -Encoding ASCII
            $workspace = Join-Path $AppDrive 'ScriptCastStudioData'
            if (-not (Test-Path $WorkspaceCfg)) { Set-Content -Path $WorkspaceCfg -Value $workspace -Encoding ASCII }
            New-Item -ItemType Directory -Force -Path $workspace | Out-Null
            Info("Setup is complete.`n`nEngine:`n$Existing`n`nWorkspace:`n$workspace`n`nLaunch ScriptCast Studio again if it does not open automatically.")
            exit 0
        }
    }

    Info("ScriptCast will now install its local speech engine.`n`nRecommended free space: at least 4 GB.`n`nThe large virtual environment, model cache, pip cache, Torch cache, and temporary generation files will be stored on the drive you choose.`n`nIf Python 3.12 itself is missing, Windows Package Manager may install the small base Python runtime in your Windows user profile.")

    $defaultParent = $AppDrive + '\'
    $parent = Choose-Parent 'Choose the DRIVE or parent folder where ScriptCastEngine should be created.' $defaultParent
    if (-not $parent) { Write-Host 'Setup cancelled.'; exit 2 }
    if ((Split-Path $parent -Leaf) -ieq 'ScriptCastEngine') { $Root = $parent } else { $Root = Join-Path $parent 'ScriptCastEngine' }

    if ($Root.Length -gt 70) {
        ErrorBox("The selected engine path is too long:`n`n$Root`n`nChoose a short location such as D:\ScriptCastEngine. Short paths prevent native Windows DLL loading problems.")
        exit 3
    }

    $driveRoot = [IO.Path]::GetPathRoot($Root)
    try {
        $drive = [IO.DriveInfo]::new($driveRoot)
        $freeGb = [math]::Round($drive.AvailableFreeSpace / 1GB, 1)
        if ($drive.AvailableFreeSpace -lt 4GB) {
            if (-not (WarnYesNo("Only $freeGb GB is free on $driveRoot. ScriptCast recommends at least 4 GB free for installation and model/cache growth.`n`nContinue anyway?", 'Low disk space'))) { exit 4 }
        }
    } catch {}

    $workspaceRoot = [IO.Path]::GetPathRoot($Root).TrimEnd('\') + '\ScriptCastStudioData'
    New-Item -ItemType Directory -Force -Path $Root, $workspaceRoot | Out-Null
    Set-Content -Path $EngineCfg -Value $Root -Encoding ASCII
    Set-Content -Path $WorkspaceCfg -Value $workspaceRoot -Encoding ASCII
    Set-EngineEnvironment $Root

    Write-Host "Engine location:    $Root"
    Write-Host "Project workspace:  $workspaceRoot"
    Write-Host ''

    $base = Find-Python312
    if (-not $base) {
        $winget = Get-Command winget -ErrorAction SilentlyContinue
        if (-not $winget) {
            ErrorBox("Python 3.12 is required, and Windows Package Manager (winget) was not found.`n`nInstall Python 3.12 from python.org, then run FIRST_RUN_SETUP.cmd again.")
            Start-Process 'https://www.python.org/downloads/windows/'
            exit 5
        }
        if (-not (WarnYesNo("Python 3.12 is not installed.`n`nAllow ScriptCast to install Python 3.12 using Windows Package Manager?", 'Python required'))) { exit 6 }
        Write-Host 'Installing Python 3.12 with winget...' -ForegroundColor Cyan
        & winget install --id Python.Python.3.12 -e --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { throw 'Python 3.12 installation did not complete successfully.' }
        Start-Sleep -Seconds 2
        $base = Find-Python312
        if (-not $base) { throw 'Python 3.12 was installed but this setup process cannot locate it yet. Restart Windows or rerun setup.' }
    }

    $Venv = Join-Path $Root 'venv'
    $Py = Join-Path $Venv 'Scripts\python.exe'
    if (-not (Test-Path $Py)) {
        Write-Host 'Creating isolated Python environment...' -ForegroundColor Cyan
        & $base -m venv $Venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the ScriptCast Python environment.' }
    }

    Run-External $Py @('-m','pip','install','--upgrade','pip') 'Updating pip'
    Run-External $Py @('-m','pip','install','-r',$Requirements) 'Installing Kokoro and media dependencies'
    Run-External $Py @('-c','import kokoro, soundfile, numpy, lameenc, PIL, imageio_ffmpeg; print("Core imports OK")') 'Testing installed libraries'

    Write-Host ''
    Write-Host 'Running first voice test. The first run may download the Kokoro model and selected voice...' -ForegroundColor Cyan
    Run-External $Py @($SmokeTest,'--engine-root',$Root) 'Generating local smoke-test audio'

    if (-not (Test-Engine $Root)) { throw 'Final engine verification failed.' }

    Write-Host ''
    Write-Host 'SETUP COMPLETE' -ForegroundColor Green
    Write-Host "Engine:    $Root"
    Write-Host "Workspace: $workspaceRoot"
    Write-Host ''
    Info("ScriptCast is ready.`n`nEngine:`n$Root`n`nWorkspace:`n$workspaceRoot`n`nThe first voice test completed successfully.")
    exit 0
}
catch {
    Write-Host ''
    Write-Host 'SETUP FAILED' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    ErrorBox("Setup did not complete.`n`n$($_.Exception.Message)`n`nThe console window contains the detailed installation output. You can rerun FIRST_RUN_SETUP.cmd after correcting the issue.")
    exit 1
}
