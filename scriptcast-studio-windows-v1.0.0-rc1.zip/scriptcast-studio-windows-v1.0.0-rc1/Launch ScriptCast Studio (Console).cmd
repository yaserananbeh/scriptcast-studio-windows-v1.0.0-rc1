@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0scriptcast_env.bat"
if not defined PY (
  echo No local engine is configured. Run FIRST_RUN_SETUP.cmd.
  pause
  exit /b 1
)
if not exist "%PY%" (
  echo Configured engine Python is missing: %PY%
  pause
  exit /b 1
)
echo ScriptCast Studio 1.0.0-rc1 - diagnostic console
echo Engine: %SCRIPTCAST_ENGINE_ROOT%
echo Workspace: %SCRIPTCAST_WORKSPACE%
echo.
"%PY%" "%~dp0server.py" --port 8765
pause
