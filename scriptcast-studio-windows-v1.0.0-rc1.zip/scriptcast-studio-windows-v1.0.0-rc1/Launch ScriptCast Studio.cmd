@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0scriptcast_env.bat"

rem First-run experience: a new user should not have to know what Python,
rem venv, pip, Kokoro, or Hugging Face are. If no engine exists, open the
rem guided setup and continue automatically when it succeeds.
if not defined PY goto firstrun
if not exist "%PY%" goto firstrun

"%PY%" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if errorlevel 1 goto badpython

goto startbackend

:firstrun
echo.
echo ScriptCast Studio needs its local voice engine before first use.
echo Opening guided setup...
echo.
call "%~dp0FIRST_RUN_SETUP.cmd"
if errorlevel 1 exit /b 1
call "%~dp0scriptcast_env.bat"
if not defined PY goto setupfailed
if not exist "%PY%" goto setupfailed
"%PY%" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if errorlevel 1 goto setupfailed

goto startbackend

:startbackend
rem If an older ScriptCast backend is still listening on 8765, stop ONLY that
rem ScriptCast process so this build never opens against a stale server.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { $s=Invoke-RestMethod -TimeoutSec 1 http://127.0.0.1:8765/api/status; if($s.version -and $s.version -ne '1.0.0-rc1'){ $c=Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1; if($c){ Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500 } } } catch {}" >nul 2>&1

rem Keep Kokoro under normal python.exe with real redirected stdout/stderr handles,
rem while launch_backend.pyw suppresses the console window.
if exist "%PYW%" (
  start "" /b "%PYW%" "%~dp0launch_backend.pyw"
) else (
  start "" /b "%PY%" "%~dp0launch_backend.pyw"
)

for /l %%i in (1,1,30) do (
  powershell -NoProfile -Command "try{$r=Invoke-RestMethod -TimeoutSec 1 http://127.0.0.1:8765/api/status; if($r.version -eq '1.0.0-rc1'){exit 0}}catch{}; exit 1" >nul 2>&1
  if not errorlevel 1 goto openapp
  timeout /t 1 /nobreak >nul
)

echo.
echo ScriptCast Studio could not start the v1.0.0-rc1 backend.
echo.
echo Engine Python:
echo   %PY%
echo.
echo Open this log for the exact startup error:
echo   %SCRIPTCAST_WORKSPACE%\logs\scriptcast-server.log
echo.
echo You can also run "Launch ScriptCast Studio (Console).cmd".
echo.
pause
exit /b 1

:openapp
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="http://127.0.0.1:8765" --start-maximized
  exit /b 0
)
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --app="http://127.0.0.1:8765" --start-maximized
  exit /b 0
)
start "" "http://127.0.0.1:8765"
exit /b 0

:badpython
echo.
echo The configured ScriptCast Python environment exists but is not working correctly.
echo Opening the repair tool...
echo.
call "%~dp0REPAIR_ENGINE.cmd"
exit /b %errorlevel%

:setupfailed
echo.
echo First-run setup finished without a usable engine.
echo Run FIRST_RUN_SETUP.cmd again or DIAGNOSE_ENGINE.bat for details.
echo.
pause
exit /b 1
