SCRIPTCAST STUDIO 1.0.0 RELEASE CANDIDATE
========================================

WHAT THIS PACKAGE DOES
----------------------
ScriptCast Studio turns scripts into local neural speech, multi-speaker audio,
subtitles, and simple portrait/image video. It uses the free Kokoro speech
engine locally; normal use does not require an API key or paid account.

FIRST RUN ON A NEW WINDOWS PC
----------------------------
1. Extract the ZIP to a normal folder. A short path on a drive with free space
   is recommended, for example D:\ScriptCastStudio.
2. Double-click:
      Launch ScriptCast Studio.cmd
3. If no compatible engine exists, the launcher automatically opens the
   First Run Setup wizard.
4. Choose where the heavy local engine should live. A short location such as
      D:\ScriptCastEngine
   is recommended. Plan for at least 4 GB free so package/model caches can grow.
5. The setup checks Python 3.12. If it is missing, it can install it using
   Windows Package Manager. The large virtual environment, Kokoro/model cache,
   pip cache, Torch cache and temporary generation files stay at the engine
   location you chose.
6. Setup installs the local packages, performs import checks, downloads the
   Kokoro model/voice needed by the smoke test, and generates a tiny test WAV.
7. When setup reports READY, launch ScriptCast normally.

EXISTING KOKORO USERS
---------------------
- The first-run wizard can automatically detect common ScriptCast/PrepLab
  engine locations and offer to reuse them.
- USE_EXISTING_ENGINE.cmd lets an advanced user select any compatible engine
  root containing venv\Scripts\python.exe.
- USE_EXISTING_PREPLAB_ENGINE.bat remains as a compatibility helper for the
  original PrepLab installation used during ScriptCast development.

INSIDE THE APP
--------------
Open "Getting Started" in the sidebar for:
- live engine/dependency health checks
- storage/free-space information
- first-project instructions
- sharing/setup instructions
- buttons to open engine/workspace/log folders
- the repair launcher

NORMAL PROJECT WORKFLOW
-----------------------
1. Create a project and choose a project type.
2. Paste a script using Speaker: text, [Speaker], or [pause 700].
3. Click Detect speakers.
4. Choose actor names, accent, gender, voice, speed, and pause timing.
5. Audition actors or individual lines.
6. Generate MP3/WAV/SRT and optionally MP4.
7. Unchanged lines are reused automatically from cache.

MAINTENANCE
-----------
DIAGNOSE_ENGINE.bat
  Runs Python, Kokoro, dependency, FFmpeg, and synthesis smoke tests.

REPAIR_ENGINE.cmd
  Rechecks/repairs the configured environment and performs another synthesis
  smoke test. Close ScriptCast before allowing package repair to proceed.

FIRST_RUN_SETUP.cmd
  Re-run this if you want to repair/reconfigure from the beginning or if there
  is no usable local engine.

SET_WORKSPACE_LOCATION.bat
  Changes where projects, caches, uploaded images and renders are stored.

STORAGE
-------
The setup deliberately separates the application from heavy engine data.
Typical layout:
  D:\ScriptCastEngine
      venv\
      hf\
      pip-cache\
      torch\
      temp\

  D:\ScriptCastStudioData
      projects\
      auditions\
      batch_exports\
      logs\

ScriptCast avoids requiring the heavy AI/model files on C: when another drive
is selected. Python itself may still use a small Windows user-profile install
when installed through Windows Package Manager.

PRIVACY
-------
Scripts and generated project files remain local. The desktop control server
binds only to 127.0.0.1 (your own computer). Public model files may be downloaded
during initial setup/first use.

RELEASE STATUS
--------------
This is the ScriptCast Studio 1.0.0 release candidate. The core production
workflow is intentionally frozen from v0.2; this release candidate focuses on
first-run setup, guidance, diagnostics, repair, and shareability.
