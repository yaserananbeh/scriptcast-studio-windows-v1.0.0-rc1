@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ScriptCast Studio - Repair Engine
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0REPAIR_ENGINE.ps1"
exit /b %errorlevel%
