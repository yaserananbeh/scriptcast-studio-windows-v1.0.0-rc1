$ErrorActionPreference='Stop'
$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$EngineCfg=Join-Path $AppDir 'engine_location.txt'
$Req=Join-Path $AppDir 'engine_requirements.txt'
$Smoke=Join-Path $AppDir 'engine_smoke_test.py'
if(-not (Test-Path $EngineCfg)){ Write-Host 'No configured engine. Run FIRST_RUN_SETUP.cmd first.' -ForegroundColor Yellow; Read-Host 'Press Enter'; exit 2 }
$Root=(Get-Content $EngineCfg | Select-Object -First 1).Trim()
$Py=Join-Path $Root 'venv\Scripts\python.exe'
$env:HF_HOME=Join-Path $Root 'hf'; $env:HUGGINGFACE_HUB_CACHE=Join-Path $env:HF_HOME 'hub'; $env:PIP_CACHE_DIR=Join-Path $Root 'pip-cache'; $env:TORCH_HOME=Join-Path $Root 'torch'; $env:XDG_CACHE_HOME=Join-Path $Root 'xdg-cache'; $env:TEMP=Join-Path $Root 'temp'; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
Write-Host 'ScriptCast Studio - Engine Repair' -ForegroundColor Cyan
Write-Host '=================================' -ForegroundColor Cyan
Write-Host "Engine: $Root"
Write-Host ''
try {
  if(-not (Test-Path $Py)){
    Write-Host 'The virtual environment is missing. Rebuilding it...' -ForegroundColor Yellow
    & py -3.12 -c "import sys" 2>$null | Out-Null
    if($LASTEXITCODE -ne 0){ throw 'Python 3.12 is not available. Run FIRST_RUN_SETUP.cmd instead.' }
    & py -3.12 -m venv (Join-Path $Root 'venv')
    if($LASTEXITCODE -ne 0){ throw 'Could not rebuild the virtual environment.' }
  }
  & $Py -m pip install --upgrade pip
  if($LASTEXITCODE -ne 0){ throw 'pip upgrade failed.' }
  & $Py -m pip install -r $Req
  if($LASTEXITCODE -ne 0){ throw 'Dependency repair failed.' }
  & $Py -c "import kokoro, soundfile, numpy, lameenc, PIL, imageio_ffmpeg; print('Imports OK')"
  if($LASTEXITCODE -ne 0){ throw 'Core import test failed after repair.' }
  & $Py $Smoke --engine-root $Root
  if($LASTEXITCODE -ne 0){ throw 'Voice synthesis test failed after repair.' }
  Write-Host ''
  Write-Host 'REPAIR COMPLETE - engine is healthy.' -ForegroundColor Green
  Write-Host 'You can relaunch ScriptCast Studio.'
  Read-Host 'Press Enter to close'
  exit 0
} catch {
  Write-Host ''
  Write-Host ('REPAIR FAILED: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host 'If this persists, run FIRST_RUN_SETUP.cmd to rebuild/reconfigure the engine.'
  Read-Host 'Press Enter to close'
  exit 1
}
