@echo off
rem Compatibility entry point. The v1 first-run wizard handles storage choice,
rem Python installation, dependency setup, model warm-up, and verification.
call "%~dp0FIRST_RUN_SETUP.cmd"
exit /b %errorlevel%
