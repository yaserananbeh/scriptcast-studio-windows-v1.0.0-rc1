@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ScriptCast Studio - project workspace location
echo ================================================
echo Projects, caches, uploaded portraits, and finished renders are stored here.
echo The speech model/engine location is configured separately.
echo.
set "DEFAULT=%~d0\ScriptCastStudioData"
set /p "DEST=Workspace path [%DEFAULT%]: "
if not defined DEST set "DEST=%DEFAULT%"
if not exist "%DEST%" mkdir "%DEST%" 2>nul
if not exist "%DEST%" (
  echo Could not create: %DEST%
  pause
  exit /b 1
)
>"%~dp0workspace_location.txt" echo %DEST%
echo.
echo Workspace set to:
echo   %DEST%
echo Restart ScriptCast Studio for the change to take effect.
pause
