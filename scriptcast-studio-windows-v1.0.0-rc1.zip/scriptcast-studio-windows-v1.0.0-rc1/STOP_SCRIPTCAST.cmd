@echo off
powershell -NoProfile -Command "$c=Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue; if($c){$p=$c.OwningProcess; Stop-Process -Id $p -Force; Write-Host ('Stopped ScriptCast process '+$p)} else {Write-Host 'ScriptCast is not running.'}"
pause
