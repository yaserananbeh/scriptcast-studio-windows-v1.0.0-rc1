@echo off
setlocal EnableExtensions
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description='Select the engine root that contains venv\Scripts\python.exe'; if($d.ShowDialog() -ne 'OK'){exit 2}; $r=$d.SelectedPath; $p=Join-Path $r 'venv\Scripts\python.exe'; if(!(Test-Path $p)){[System.Windows.Forms.MessageBox]::Show('That folder does not contain venv\Scripts\python.exe.','ScriptCast','OK','Error')|Out-Null; exit 3}; & $p -c 'import kokoro, soundfile, numpy, lameenc, PIL, imageio_ffmpeg'; if($LASTEXITCODE -ne 0){[System.Windows.Forms.MessageBox]::Show('The selected environment is not compatible with ScriptCast.','ScriptCast','OK','Error')|Out-Null; exit 4}; Set-Content -Path '%~dp0engine_location.txt' -Value $r -Encoding ASCII; [System.Windows.Forms.MessageBox]::Show(('Compatible engine configured:`n`n'+$r),'ScriptCast','OK','Information')|Out-Null"
if errorlevel 1 exit /b %errorlevel%
echo Existing engine configured successfully.
pause
