@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "CAND="
if exist "D:\PrepLabMediaStudio\venv\Scripts\python.exe" set "CAND=D:\PrepLabMediaStudio"
if not defined CAND if exist "%~d0\PrepLabMediaStudio\venv\Scripts\python.exe" set "CAND=%~d0\PrepLabMediaStudio"
if not defined CAND if exist "%LOCALAPPDATA%\PrepLabMediaStudio\venv\Scripts\python.exe" set "CAND=%LOCALAPPDATA%\PrepLabMediaStudio"
if not defined CAND (
  echo No PrepLab Media Studio environment was found automatically.
  echo Run SETUP_ENGINE.bat instead.
  pause
  exit /b 1
)
echo Found: %CAND%
"%CAND%\venv\Scripts\python.exe" -c "from kokoro import KPipeline; import soundfile, numpy, lameenc, PIL, imageio_ffmpeg; print('Engine import OK')"
if errorlevel 1 (
  echo The detected environment is incomplete.
  pause
  exit /b 1
)
>"%~dp0engine_location.txt" echo %CAND%
echo.
echo ScriptCast is configured to reuse this engine:
echo   %CAND%
echo No models or Python packages were duplicated.
echo.
echo Next: run "Launch ScriptCast Studio.cmd"
pause
