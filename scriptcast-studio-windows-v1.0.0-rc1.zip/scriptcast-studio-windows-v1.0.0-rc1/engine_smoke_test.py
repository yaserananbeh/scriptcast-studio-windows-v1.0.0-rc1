from __future__ import annotations
import argparse
from pathlib import Path
import os

ap = argparse.ArgumentParser()
ap.add_argument('--engine-root', required=True)
args = ap.parse_args()
root = Path(args.engine_root)
os.environ.setdefault('HF_HOME', str(root / 'hf'))
os.environ.setdefault('HUGGINGFACE_HUB_CACHE', str(root / 'hf' / 'hub'))
os.environ.setdefault('TORCH_HOME', str(root / 'torch'))
os.environ.setdefault('XDG_CACHE_HOME', str(root / 'xdg-cache'))

from kokoro import KPipeline
import numpy as np
import soundfile as sf

pipe = KPipeline(lang_code='a')
chunks = []
for _gs, _ps, audio in pipe('ScriptCast Studio is ready for local voice generation.', voice='af_heart', speed=1.0):
    chunks.append(np.asarray(audio, dtype=np.float32))
if not chunks:
    raise RuntimeError('Kokoro returned no audio during setup test.')
out = root / 'temp' / 'scriptcast-setup-test.wav'
out.parent.mkdir(parents=True, exist_ok=True)
sf.write(str(out), np.concatenate(chunks), 24000, subtype='PCM_16')
print('Kokoro synthesis OK')
print('Test audio:', out)
