"""ScriptCast Studio hidden backend launcher (v1.0.0-rc1).

Kokoro 0.9.4 configures Loguru with ``logger.add(sys.stderr, ...)`` while the
package is imported.  A server process run directly by pythonw.exe can have
``sys.stderr is None`` on Windows, causing:

    TypeError: Cannot log to objects of type 'NoneType'

This tiny pythonw bootstrap does NOT import Kokoro.  Instead, it starts the
normal console Python executable with stdout/stderr explicitly redirected to a
real UTF-8 log file and CREATE_NO_WINDOW.  The backend therefore remains
invisible to the user while Kokoro receives valid standard streams.
"""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
workspace = Path(os.environ.get("SCRIPTCAST_WORKSPACE", str(HERE / "workspace"))).resolve()
logs = workspace / "logs"
logs.mkdir(parents=True, exist_ok=True)
log_path = logs / "scriptcast-server.log"

exe = Path(sys.executable)
python_exe = exe.with_name("python.exe") if exe.name.lower() == "pythonw.exe" else exe
if not python_exe.exists():
    python_exe = exe

# Use an OS-level file handle for BOTH streams.  This is stronger than merely
# assigning sys.stderr inside the backend after pythonw has initialized.
log = open(log_path, "a", encoding="utf-8", buffering=1)
creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
try:
    subprocess.Popen(
        [str(python_exe), str(HERE / "server.py"), "--port", "8765"],
        cwd=str(HERE),
        env=os.environ.copy(),
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=log,
        creationflags=creationflags,
        close_fds=False,
    )
except Exception as exc:
    log.write(f"Hidden backend launcher failed: {type(exc).__name__}: {exc}\n")
    log.flush()
finally:
    log.close()
