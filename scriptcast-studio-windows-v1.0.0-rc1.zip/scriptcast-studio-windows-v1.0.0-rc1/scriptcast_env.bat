@echo off
rem ScriptCast Studio shared environment configuration (v1.0.0-rc1).
rem This file intentionally has NO setlocal so variables remain available to the launcher.
set "SCRIPTCAST_ENGINE_ROOT="
set "SCRIPTCAST_WORKSPACE="
set "ENGINE_CFG=%~dp0engine_location.txt"
set "WORKSPACE_CFG=%~dp0workspace_location.txt"

rem 1) Read explicitly configured locations.
if exist "%ENGINE_CFG%" (
  for /f "usebackq delims=" %%A in ("%ENGINE_CFG%") do if not defined SCRIPTCAST_ENGINE_ROOT set "SCRIPTCAST_ENGINE_ROOT=%%A"
)
if defined SCRIPTCAST_ENGINE_ROOT if not exist "%SCRIPTCAST_ENGINE_ROOT%\venv\Scripts\python.exe" set "SCRIPTCAST_ENGINE_ROOT="

rem 2) Auto-detect common compatible local engines.
if not defined SCRIPTCAST_ENGINE_ROOT if exist "%~d0\ScriptCastEngine\venv\Scripts\python.exe" set "SCRIPTCAST_ENGINE_ROOT=%~d0\ScriptCastEngine"
if not defined SCRIPTCAST_ENGINE_ROOT if exist "D:\PrepLabMediaStudio\venv\Scripts\python.exe" set "SCRIPTCAST_ENGINE_ROOT=D:\PrepLabMediaStudio"
if not defined SCRIPTCAST_ENGINE_ROOT if exist "%~d0\PrepLabMediaStudio\venv\Scripts\python.exe" set "SCRIPTCAST_ENGINE_ROOT=%~d0\PrepLabMediaStudio"
if not defined SCRIPTCAST_ENGINE_ROOT if exist "%LOCALAPPDATA%\PrepLabMediaStudio\venv\Scripts\python.exe" set "SCRIPTCAST_ENGINE_ROOT=%LOCALAPPDATA%\PrepLabMediaStudio"

rem 3) Workspace can be configured independently.
if exist "%WORKSPACE_CFG%" (
  for /f "usebackq delims=" %%A in ("%WORKSPACE_CFG%") do if not defined SCRIPTCAST_WORKSPACE set "SCRIPTCAST_WORKSPACE=%%A"
)
if not defined SCRIPTCAST_WORKSPACE set "SCRIPTCAST_WORKSPACE=%~d0\ScriptCastStudioData"

if defined SCRIPTCAST_ENGINE_ROOT (
  set "VENV=%SCRIPTCAST_ENGINE_ROOT%\venv"
  set "PY=%SCRIPTCAST_ENGINE_ROOT%\venv\Scripts\python.exe"
  set "PYW=%SCRIPTCAST_ENGINE_ROOT%\venv\Scripts\pythonw.exe"
  set "HF_HOME=%SCRIPTCAST_ENGINE_ROOT%\hf"
  set "HUGGINGFACE_HUB_CACHE=%SCRIPTCAST_ENGINE_ROOT%\hf\hub"
  set "PIP_CACHE_DIR=%SCRIPTCAST_ENGINE_ROOT%\pip-cache"
  set "TORCH_HOME=%SCRIPTCAST_ENGINE_ROOT%\torch"
  set "XDG_CACHE_HOME=%SCRIPTCAST_ENGINE_ROOT%\xdg-cache"
  set "TEMP=%SCRIPTCAST_ENGINE_ROOT%\temp"
  set "TMP=%SCRIPTCAST_ENGINE_ROOT%\temp"
  if not exist "%TEMP%" mkdir "%TEMP%" >nul 2>&1
)
if not exist "%SCRIPTCAST_WORKSPACE%" mkdir "%SCRIPTCAST_WORKSPACE%" >nul 2>&1
