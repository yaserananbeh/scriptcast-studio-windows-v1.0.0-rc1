from __future__ import annotations
import argparse, base64, csv, hashlib, io, json, math, mimetypes, os, pathlib, re, shutil, subprocess, sys, threading, time, uuid, wave
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote

APP_VERSION = "1.0.0-rc1"
HERE = pathlib.Path(__file__).resolve().parent
STATIC = HERE / "static"
ENGINE_ROOT = pathlib.Path(os.environ.get("SCRIPTCAST_ENGINE_ROOT", "")) if os.environ.get("SCRIPTCAST_ENGINE_ROOT") else None
WORKSPACE = pathlib.Path(os.environ.get("SCRIPTCAST_WORKSPACE", str(HERE / "workspace"))).resolve()
PROJECTS = WORKSPACE / "projects"
BATCH = WORKSPACE / "batch_exports"
TEMP = WORKSPACE / "temp"
for d in (WORKSPACE, PROJECTS, BATCH, TEMP): d.mkdir(parents=True, exist_ok=True)
ACTOR_LIBRARY_FILE = WORKSPACE / "actor_library.json"
PRONUNCIATION_FILE = WORKSPACE / "pronunciations.json"

# pythonw.exe intentionally starts without console stdout/stderr streams on Windows.
# Some Kokoro dependencies (notably logging libraries imported during KPipeline
# construction) expect a real writable stream. If they receive None they can fail
# with errors such as: "Cannot log to objects of type 'NoneType'".
# Keep the normal console streams when launched diagnostically with python.exe, but
# provide a persistent UTF-8 log sink when ScriptCast is launched invisibly.
BACKGROUND_LOG = None
def ensure_background_stdio():
    global BACKGROUND_LOG
    if sys.stdout is not None and sys.stderr is not None:
        return
    logs = WORKSPACE / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log_path = logs / "scriptcast-server.log"
    BACKGROUND_LOG = open(log_path, "a", encoding="utf-8", buffering=1)
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    BACKGROUND_LOG.write(f"\n[{stamp}] ScriptCast Studio {APP_VERSION} background server starting\n")
    if sys.stdout is None:
        sys.stdout = BACKGROUND_LOG
    if sys.stderr is None:
        sys.stderr = BACKGROUND_LOG

ensure_background_stdio()

VOICE_CATALOG = [
    {"id":"af_heart","name":"Heart","accent":"American","gender":"Female","style":"Warm, clear narrator"},
    {"id":"af_bella","name":"Bella","accent":"American","gender":"Female","style":"Conversational, bright"},
    {"id":"am_fenrir","name":"Fenrir","accent":"American","gender":"Male","style":"Energetic, conversational"},
    {"id":"am_michael","name":"Michael","accent":"American","gender":"Male","style":"Steady, neutral"},
    {"id":"bf_emma","name":"Emma","accent":"British","gender":"Female","style":"Clear, polished"},
    {"id":"bm_george","name":"George","accent":"British","gender":"Male","style":"Measured, academic"},
    {"id":"bm_fable","name":"Fable","accent":"British","gender":"Male","style":"Lighter, expressive"},
]
VOICE_IDS = {v["id"] for v in VOICE_CATALOG}
DEFAULT_BY_PROFILE = {
    ("American","Female"): "af_heart",
    ("American","Male"): "am_michael",
    ("British","Female"): "bf_emma",
    ("British","Male"): "bm_george",
}

JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
LAST_HEARTBEAT = time.time()
HAD_HEARTBEAT = False
SERVER_REF = None
PIPELINES = None
PIPELINES_LOCK = threading.Lock()
SYNTH_LOCK = threading.Lock()


def safe_name(s: str, fallback="project") -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", (s or "").strip()).strip("-._")
    return (s[:80] or fallback)


def ensure_project_id(project: dict) -> str:
    pid = safe_name(project.get("id", ""), "")
    if not pid:
        pid = f"p-{uuid.uuid4().hex[:12]}"
        project["id"] = pid
    return pid


def project_dir(pid: str) -> pathlib.Path:
    p = (PROJECTS / safe_name(pid)).resolve()
    if PROJECTS not in p.parents and p != PROJECTS:
        raise ValueError("Invalid project path")
    p.mkdir(parents=True, exist_ok=True)
    return p


def read_json(path: pathlib.Path, default=None):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return default


def write_json(path: pathlib.Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def actor_library():
    data=read_json(ACTOR_LIBRARY_FILE, [])
    return data if isinstance(data,list) else []


def pronunciation_entries():
    data=read_json(PRONUNCIATION_FILE, [])
    return data if isinstance(data,list) else []


def prepare_speech_text(text: str) -> str:
    """Apply user pronunciation replacements only to synthesis text.

    Captions and project scripts remain unchanged. Entries are applied longest-first
    so a phrase can override a shorter word contained inside it.
    """
    out=str(text or "")
    entries=[e for e in pronunciation_entries() if str(e.get("term","")).strip() and str(e.get("replacement","")).strip()]
    entries.sort(key=lambda e: len(str(e.get("term",""))), reverse=True)
    for e in entries:
        term=str(e.get("term","")).strip(); repl=str(e.get("replacement","")).strip()
        pat=re.escape(term)
        if term and term[0].isalnum(): pat=r"(?<!\w)"+pat
        if term and term[-1].isalnum(): pat=pat+r"(?!\w)"
        flags=0 if e.get("case_sensitive") else re.I
        out=re.sub(pat, lambda _m, r=repl:r, out, flags=flags)
    return out


def compact_actor(actor: dict) -> dict:
    return {
        "id": safe_name(actor.get("id") or actor.get("library_id") or "", "") or f"actor-{uuid.uuid4().hex[:10]}",
        "actor_name": str(actor.get("actor_name") or actor.get("name") or "Actor").strip() or "Actor",
        "accent": actor.get("accent","American"),
        "gender": actor.get("gender","Female"),
        "voice": actor.get("voice","af_heart"),
        "speed": float(actor.get("speed",1.0)),
        "pause_ms": int(float(actor.get("pause_ms",350))),
    }


def parse_script(script: str):
    lines=[]; current="Narrator"; pending_opts={}
    for raw in (script or "").replace("\r\n","\n").split("\n"):
        line=raw.strip()
        if not line: continue
        pm=re.fullmatch(r"\[\s*pause\s+(\d{1,5})\s*\]", line, flags=re.I)
        if pm:
            lines.append({"kind":"pause","speaker":"","text":"","pause_ms":min(10000,int(pm.group(1)))})
            continue
        hm=re.match(r"^\[([^\]]+)\]\s*(.*)$", line)
        if hm:
            header=hm.group(1).strip(); rest=hm.group(2).strip()
            parts=header.split(); speaker_parts=[]; opts={}
            for part in parts:
                if "=" in part:
                    k,v=part.split("=",1); k=k.lower().strip(); v=v.strip()
                    if k in ("speed","pause"):
                        try: opts[k]=float(v) if k=="speed" else int(float(v))
                        except: pass
                else: speaker_parts.append(part)
            if speaker_parts: current=" ".join(speaker_parts)
            pending_opts=opts
            if rest:
                item={"kind":"speech","speaker":current,"text":rest}
                if "speed" in opts: item["speed"]=opts["speed"]
                if "pause" in opts: item["pause_ms"]=opts["pause"]
                lines.append(item); pending_opts={}
            continue
        sm=re.match(r"^([A-Za-z][A-Za-z0-9 _.'-]{0,48}):\s+(.+)$", line)
        if sm:
            current=sm.group(1).strip(); text=sm.group(2).strip()
            item={"kind":"speech","speaker":current,"text":text}
            lines.append(item); pending_opts={}
            continue
        item={"kind":"speech","speaker":current,"text":line}
        if "speed" in pending_opts: item["speed"]=pending_opts["speed"]
        if "pause" in pending_opts: item["pause_ms"]=pending_opts["pause"]
        lines.append(item); pending_opts={}
    speakers=[]
    for x in lines:
        if x["kind"]=="speech" and x["speaker"] not in speakers: speakers.append(x["speaker"])
    return {"lines":lines,"speakers":speakers,"count":len([x for x in lines if x['kind']=='speech'])}


def default_actor(speaker: str, index=0):
    profiles=[("American","Female","af_heart"),("American","Male","am_michael"),("British","Female","bf_emma"),("British","Male","bm_george")]
    accent,gender,voice=profiles[index%len(profiles)]
    return {"speaker":speaker,"actor_name":speaker,"accent":accent,"gender":gender,"voice":voice,"speed":1.0,"pause_ms":350,"portrait":""}


def reconcile_actors(project: dict, speakers: list[str]):
    actors=project.setdefault("actors", {})
    for i,s in enumerate(speakers):
        if s not in actors: actors[s]=default_actor(s,i)
        else:
            a=actors[s]
            a.setdefault("speaker",s); a.setdefault("actor_name",s); a.setdefault("accent","American"); a.setdefault("gender","Female")
            a.setdefault("voice", DEFAULT_BY_PROFILE.get((a["accent"],a["gender"]),"af_heart")); a.setdefault("speed",1.0); a.setdefault("pause_ms",350); a.setdefault("portrait","")
    return actors


def voice_lang(voice: str): return "b" if str(voice).startswith("b") else "a"


def normalize(audio, peak=0.92):
    import numpy as np
    x=np.asarray(audio,dtype=np.float32).flatten()
    if not len(x): return x
    m=float(np.max(np.abs(x)))
    if m>1e-7: x=x*(float(peak)/m)
    fade=min(int(24000*0.02), len(x)//2)
    if fade>1:
        ramp=np.linspace(0,1,fade,dtype=np.float32); x[:fade]*=ramp; x[-fade:]*=ramp[::-1]
    return np.clip(x,-1,1)


def silence(ms, sr=24000):
    import numpy as np
    return np.zeros(int(sr*max(0,int(ms))/1000),dtype=np.float32)


def render_text(text, voice, speed, pipelines):
    import numpy as np
    pipe=pipelines[voice_lang(voice)]
    chunks=[]
    # Kokoro/PyTorch inference is serialized intentionally. The desktop app can
    # submit previews while a render is active, but sharing one loaded model is
    # safer and uses far less memory than constructing competing pipelines.
    with SYNTH_LOCK:
        for _gs,_ps,audio in pipe(text,voice=voice,speed=float(speed),split_pattern=r"\n+"):
            chunks.append(np.asarray(audio,dtype=np.float32))
    if not chunks: raise RuntimeError("Kokoro returned no audio")
    return normalize(np.concatenate(chunks))


def save_wav(audio, path: pathlib.Path, sr=24000):
    import soundfile as sf
    path.parent.mkdir(parents=True, exist_ok=True); sf.write(str(path), audio, sr, subtype="PCM_16")


def load_wav(path: pathlib.Path):
    import soundfile as sf, numpy as np
    audio,sr=sf.read(str(path),dtype="float32")
    if sr!=24000: raise RuntimeError(f"Expected 24000 Hz cache, got {sr}")
    if getattr(audio,"ndim",1)>1: audio=np.mean(audio,axis=1)
    return np.asarray(audio,dtype=np.float32)


def encode_mp3(audio, path: pathlib.Path, sample_rate=24000, kbps=128):
    import lameenc, numpy as np
    pcm=(np.clip(audio,-1,1)*32767.0).astype("<i2")
    enc=lameenc.Encoder(); enc.set_bit_rate(int(kbps)); enc.set_in_sample_rate(sample_rate); enc.set_channels(1); enc.set_quality(2)
    path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(enc.encode(pcm.tobytes())+enc.flush())


def cache_key(text, voice, speed):
    return hashlib.sha256(json.dumps({"text":text,"voice":voice,"speed":round(float(speed),4)},sort_keys=True).encode()).hexdigest()[:24]


def get_pipelines():
    global PIPELINES
    if PIPELINES is not None: return PIPELINES
    with PIPELINES_LOCK:
        if PIPELINES is None:
            from kokoro import KPipeline
            PIPELINES={"a":KPipeline(lang_code="a"),"b":KPipeline(lang_code="b")}
    return PIPELINES


def format_srt_time(sec):
    ms=int(round(sec*1000)); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def make_default_card(path: pathlib.Path, speaker: str, text: str, size=(1280,720)):
    from PIL import Image, ImageDraw, ImageFont
    im=Image.new("RGB",size,(18,24,38)); d=ImageDraw.Draw(im)
    try: f1=ImageFont.truetype("arial.ttf",48); f2=ImageFont.truetype("arial.ttf",28)
    except: f1=ImageFont.load_default(); f2=ImageFont.load_default()
    d.rounded_rectangle((70,70,size[0]-70,size[1]-70),radius=28,fill=(28,37,56),outline=(70,91,120),width=2)
    d.text((120,130),speaker or "Narrator",font=f1,fill=(242,245,250))
    words=text.split(); rows=[]; row=""
    for w in words:
        test=(row+" "+w).strip()
        if len(test)>62: rows.append(row); row=w
        else: row=test
    if row: rows.append(row)
    y=225
    for r in rows[:7]: d.text((120,y),r,font=f2,fill=(190,200,218)); y+=46
    d.text((120,size[1]-130),"ScriptCast Studio",font=f2,fill=(94,234,212))
    path.parent.mkdir(parents=True,exist_ok=True); im.save(path)


def ffmpeg_exe():
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def make_video(project, rendered, out_path, pdir, settings, job):
    ff=ffmpeg_exe(); segdir=pdir/"cache"/"video_segments"; segdir.mkdir(parents=True,exist_ok=True)
    global_img=settings.get("cover_image","")
    global_path=(pdir/global_img) if global_img else None
    actors=project.get("actors",{})
    segfiles=[]
    width,height=(1280,720) if settings.get("resolution","1280x720")=="1280x720" else (1920,1080)
    last_img=None; last_speaker="Narrator"
    for i,item in enumerate(rendered):
        if job.get("cancelled"): raise RuntimeError("Cancelled")
        if item.get("kind")=="speech":
            actor=actors.get(item["speaker"],{}); last_speaker=item["speaker"]
            portrait=actor.get("portrait",""); img=(pdir/portrait) if portrait else global_path
            if not img or not img.exists():
                img=segdir/f"card-{i:04}.png"; make_default_card(img,actor.get("actor_name",item["speaker"]),item["text"],(width,height))
            last_img=img
        else:
            actor=actors.get(last_speaker,{})
            img=last_img or global_path
            if not img or not img.exists():
                img=segdir/f"card-{i:04}.png"; make_default_card(img,actor.get("actor_name",last_speaker),"",(width,height)); last_img=img
        wav=pathlib.Path(item["wav_path"])
        seg=segdir/f"seg-{i:04}.mp4"
        vf=f"scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=0x0f172a,format=yuv420p"
        cmd=[ff,"-y","-loglevel","error","-loop","1","-framerate","30","-i",str(img),"-i",str(wav),"-vf",vf,"-c:v","libx264","-preset","veryfast","-tune","stillimage","-c:a","aac","-b:a","128k","-shortest",str(seg)]
        subprocess.run(cmd,check=True); segfiles.append(seg)
    if not segfiles: raise RuntimeError("No speech segments available for video")
    concat=segdir/"concat.txt"; concat.write_text("\n".join("file '"+str(x).replace("'","'\\''")+"'" for x in segfiles),encoding="utf-8")
    subprocess.run([ff,"-y","-loglevel","error","-f","concat","-safe","0","-i",str(concat),"-c","copy","-movflags","+faststart",str(out_path)],check=True)




def human_bytes(n):
    try: n=float(n)
    except Exception: return "—"
    units=["B","KB","MB","GB","TB"]
    for unit in units:
        if abs(n)<1024 or unit==units[-1]: return f"{n:.1f} {unit}" if unit!="B" else f"{int(n)} B"
        n/=1024


def engine_diagnostics():
    """Return a user-facing health snapshot without forcing a full model load."""
    checks=[]
    def add(name,ok,detail): checks.append({"name":name,"ok":bool(ok),"detail":str(detail)})
    add("Engine folder", bool(ENGINE_ROOT and ENGINE_ROOT.exists()), str(ENGINE_ROOT or "Not configured"))
    add("Python runtime", True, f"{sys.version.split()[0]} — {sys.executable}")
    try:
        import kokoro
        add("Kokoro", True, f"Version {getattr(kokoro,'__version__','installed')}")
    except Exception as e: add("Kokoro", False, str(e))
    deps=[("NumPy","numpy"),("SoundFile","soundfile"),("MP3 encoder","lameenc"),("Pillow","PIL"),("Video/FFmpeg","imageio_ffmpeg")]
    for label,mod in deps:
        try:
            m=__import__(mod)
            detail=getattr(m,'__version__','installed')
            if mod=='imageio_ffmpeg':
                try: detail=f"{detail} — {m.get_ffmpeg_exe()}"
                except Exception: pass
            add(label,True,detail)
        except Exception as e: add(label,False,str(e))
    try:
        WORKSPACE.mkdir(parents=True,exist_ok=True)
        probe=WORKSPACE/'.write-test'
        probe.write_text('ok',encoding='utf-8'); probe.unlink(missing_ok=True)
        add("Workspace writable",True,str(WORKSPACE))
    except Exception as e: add("Workspace writable",False,str(e))
    storage=[]
    for label,path in (("Engine",ENGINE_ROOT),("Workspace",WORKSPACE)):
        if path:
            try:
                use=shutil.disk_usage(str(path))
                storage.append({"label":label,"path":str(path),"free":human_bytes(use.free),"total":human_bytes(use.total),"free_bytes":use.free})
            except Exception: pass
    log_path=WORKSPACE/'logs'/'scriptcast-server.log'
    return {
        "ok":all(c['ok'] for c in checks),
        "checks":checks,
        "storage":storage,
        "engine_root":str(ENGINE_ROOT or ''),
        "workspace":str(WORKSPACE),
        "log_path":str(log_path),
        "version":APP_VERSION,
    }


def open_local_path(target: pathlib.Path):
    target=target.resolve()
    if os.name=='nt': os.startfile(str(target))
    elif sys.platform=='darwin': subprocess.Popen(['open',str(target)])
    else: subprocess.Popen(['xdg-open',str(target)])

def record_exception(context: str, exc: Exception):
    try:
        import traceback
        stamp=time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{stamp}] {context}: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        traceback.print_exc(file=sys.stderr)
    except Exception:
        pass


def render_project_job(job_id: str, project: dict, options: dict):
    job=JOBS[job_id]
    try:
        pid=ensure_project_id(project); parsed=parse_script(project.get("script","")); reconcile_actors(project,parsed["speakers"])
        pdir=project_dir(pid); (pdir/"cache"/"audio").mkdir(parents=True,exist_ok=True); (pdir/"renders").mkdir(parents=True,exist_ok=True)
        write_json(pdir/"project.json", project)
        settings=project.setdefault("settings",{})
        default_pause=int(settings.get("default_pause_ms",350)); peak=float(settings.get("peak",0.92)); kbps=int(settings.get("mp3_kbps",128))
        pipelines=get_pipelines(); import numpy as np
        speech_count=sum(1 for x in parsed["lines"] if x["kind"]=="speech"); done=0; reused=0; generated=0; combined=[]; rendered=[]; cursor=0.0; srt=[]
        job.update({"total":speech_count,"cached":0,"generated":0})
        for idx,line in enumerate(parsed["lines"]):
            if job.get("cancelled"): raise RuntimeError("Cancelled")
            if line["kind"]=="pause":
                a=silence(line.get("pause_ms",default_pause)); pause_wav=pdir/"cache"/"audio"/f"line-{idx:04}-pause.wav"; save_wav(a,pause_wav)
                combined.append(a); cursor+=len(a)/24000; rendered.append({**line,"seconds":len(a)/24000,"wav_path":str(pause_wav)}); continue
            actor=project["actors"].get(line["speaker"],default_actor(line["speaker"]))
            voice=actor.get("voice") or DEFAULT_BY_PROFILE.get((actor.get("accent"),actor.get("gender")),"af_heart")
            speed=float(line.get("speed",actor.get("speed",1.0))); pause_ms=int(line.get("pause_ms",actor.get("pause_ms",default_pause)))
            synth_text=prepare_speech_text(line["text"])
            key=cache_key(synth_text,voice,speed); wav=pdir/"cache"/"audio"/f"{key}.wav"
            if wav.exists(): spoken=load_wav(wav); cached=True; reused+=1
            else: spoken=render_text(synth_text,voice,speed,pipelines); save_wav(spoken,wav); cached=False; generated+=1
            speaking_seconds=len(spoken)/24000; start=cursor; end=cursor+speaking_seconds
            srt.append((start,end,f"{actor.get('actor_name',line['speaker'])}: {line['text']}" if len(parsed['speakers'])>1 else line['text']))
            line_audio=np.concatenate([spoken,silence(pause_ms)]); line_wav=pdir/"cache"/"audio"/f"line-{idx:04}-{key}.wav"; save_wav(line_audio,line_wav)
            combined.append(line_audio); cursor+=len(line_audio)/24000
            extra={"synth_text":synth_text} if synth_text!=line["text"] else {}
            rendered.append({**line,**extra,"voice":voice,"speed":speed,"pause_ms":pause_ms,"seconds":len(line_audio)/24000,"spoken_seconds":speaking_seconds,"cached":cached,"wav_path":str(line_wav)})
            done+=1; job.update({"stage":"Generating speech","current":done,"total":speech_count,"cached":reused,"generated":generated,"message":f"{actor.get('actor_name',line['speaker'])}: {line['text'][:68]}"})
        if not combined: raise RuntimeError("Script has no renderable lines")
        full=normalize(np.concatenate(combined),peak=peak)
        stamp=time.strftime("%Y%m%d-%H%M%S"); base=safe_name(project.get("title","scriptcast"),"scriptcast")+"-"+stamp; renders=pdir/"renders"; outputs={}
        if options.get("wav",True):
            out=renders/f"{base}.wav"; save_wav(full,out); outputs["wav"]=workspace_url(out)
        if options.get("mp3",True):
            out=renders/f"{base}.mp3"; encode_mp3(full,out,kbps=kbps); outputs["mp3"]=workspace_url(out)
        if options.get("srt",True):
            out=renders/f"{base}.srt"; txt=[]
            for i,(a,b,t) in enumerate(srt,1): txt += [str(i),f"{format_srt_time(a)} --> {format_srt_time(b)}",t,""]
            out.write_text("\n".join(txt),encoding="utf-8"); outputs["srt"]=workspace_url(out)
        if options.get("mp4",False):
            job.update({"stage":"Building video","message":"Creating video segments from portraits/images"})
            out=renders/f"{base}.mp4"; make_video(project,rendered,out,pdir,settings,job); outputs["mp4"]=workspace_url(out)
        manifest={"project_id":pid,"created":time.strftime("%Y-%m-%d %H:%M:%S"),"seconds":round(len(full)/24000,2),"lines":rendered,"outputs":outputs}
        man=renders/f"{base}.json"; write_json(man,manifest); outputs["manifest"]=workspace_url(man)
        project["updated_at"]=time.time(); project["last_render"]=outputs; write_json(pdir/"project.json",project)
        job.update({"status":"done","stage":"Complete","current":speech_count,"total":speech_count,"cached":reused,"generated":generated,"message":"Render completed","outputs":outputs,"seconds":manifest["seconds"]})
    except Exception as e:
        record_exception("Project render failed", e)
        job.update({"status":"cancelled" if str(e)=="Cancelled" else "error","stage":"Stopped","error":str(e),"message":str(e)})


def render_batch_job(job_id, rows):
    job=JOBS[job_id]
    try:
        pipelines=get_pipelines(); import numpy as np
        outdir=BATCH/time.strftime("%Y%m%d-%H%M%S"); outdir.mkdir(parents=True,exist_ok=True); results=[]
        for i,row in enumerate(rows,1):
            if job.get("cancelled"): raise RuntimeError("Cancelled")
            text=str(row.get("text","")).strip(); voice=str(row.get("voice","af_heart")).strip() or "af_heart"; speed=float(row.get("speed",1) or 1)
            if not text: continue
            audio=render_text(prepare_speech_text(text),voice,speed,pipelines); filename=safe_name(str(row.get("filename",f"clip-{i:03}")))
            if not filename.lower().endswith(".mp3"): filename += ".mp3"
            path=outdir/filename; encode_mp3(audio,path); results.append({"file":workspace_url(path),"text":text,"voice":voice})
            job.update({"stage":"Batch generation","current":i,"total":len(rows),"message":filename})
        job.update({"status":"done","stage":"Complete","message":f"Generated {len(results)} files","outputs":{"folder":workspace_url(outdir),"files":results}})
    except Exception as e:
        record_exception("Batch render failed", e)
        job.update({"status":"error","stage":"Stopped","error":str(e),"message":str(e)})


def workspace_url(path: pathlib.Path):
    path=path.resolve(); rel=path.relative_to(WORKSPACE); return "/workspace/"+"/".join(rel.parts)


def project_summary(path: pathlib.Path):
    p=read_json(path,{}) or {}
    return {"id":p.get("id",path.parent.name),"title":p.get("title","Untitled"),"type":p.get("type","Narration"),"updated_at":p.get("updated_at",0),"speakers":len(p.get("actors",{})),"last_render":p.get("last_render",{})}


def sample_project():
    script="""Maya: I thought the workshop started at three.\nDaniel: It usually does, but today's session was moved to three thirty.\nMaya: Good thing I checked. Do we still meet in the media lab?\nDaniel: Yes. The room is the same; only the time changed.\n[pause 700]\nNarrator: This sample demonstrates speaker detection, per-actor voices, natural pauses, caching, subtitles, and optional portrait video."""
    p={"id":"","title":"Campus conversation demo","type":"Conversation","script":script,"actors":{},"settings":{"default_pause_ms":340,"peak":0.92,"mp3_kbps":128,"resolution":"1280x720","cover_image":""}}
    parsed=parse_script(script); reconcile_actors(p,parsed["speakers"]); p["actors"]["Maya"].update({"accent":"American","gender":"Female","voice":"af_bella","speed":1.01,"pause_ms":280}); p["actors"]["Daniel"].update({"accent":"British","gender":"Male","voice":"bm_george","speed":0.98,"pause_ms":300}); p["actors"]["Narrator"].update({"accent":"American","gender":"Female","voice":"af_heart","speed":0.95,"pause_ms":400}); return p


class Handler(BaseHTTPRequestHandler):
    server_version="ScriptCastStudio/1.0"
    def log_message(self, fmt,*args): pass
    def send_json(self,data,status=200):
        raw=json.dumps(data,ensure_ascii=False).encode()
        try:
            self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(raw))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(raw)
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
            return False
        except OSError as e:
            if getattr(e,"winerror",None) in (10053,10054): return False
            raise
        return True
    def send_file(self,path: pathlib.Path):
        if not path.exists() or not path.is_file(): self.send_error(404); return
        c=mimetypes.guess_type(str(path))[0] or "application/octet-stream"; size=path.stat().st_size
        rng=self.headers.get("Range","")
        if rng.startswith("bytes="):
            try:
                spec=rng[6:].split(",",1)[0]; a,b=spec.split("-",1); start=int(a) if a else 0; end=int(b) if b else size-1; end=min(end,size-1)
                if start<0 or start>=size or end<start: raise ValueError
                length=end-start+1
                self.send_response(206); self.send_header("Content-Type",c); self.send_header("Content-Length",str(length)); self.send_header("Content-Range",f"bytes {start}-{end}/{size}"); self.send_header("Accept-Ranges","bytes"); self.end_headers()
                with path.open("rb") as f:
                    f.seek(start); remaining=length
                    while remaining:
                        chunk=f.read(min(1024*1024,remaining))
                        if not chunk: break
                        try: self.wfile.write(chunk)
                        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError): return
                        except OSError as e:
                            if getattr(e,"winerror",None) in (10053,10054): return
                            raise
                        remaining-=len(chunk)
                return
            except Exception: pass
        self.send_response(200); self.send_header("Content-Type",c); self.send_header("Content-Length",str(size)); self.send_header("Accept-Ranges","bytes"); self.end_headers()
        with path.open("rb") as f:
            while True:
                chunk=f.read(1024*1024)
                if not chunk: break
                try: self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError): return
                except OSError as e:
                    if getattr(e,"winerror",None) in (10053,10054): return
                    raise
    def body_json(self):
        n=int(self.headers.get("Content-Length","0") or 0); raw=self.rfile.read(n) if n else b"{}"; return json.loads(raw.decode("utf-8"))
    def do_GET(self):
        u=urlparse(self.path); path=u.path; qs=parse_qs(u.query)
        if path=="/": return self.send_file(STATIC/"index.html")
        if path.startswith("/static/"):
            p=(STATIC/path[len("/static/"):]).resolve()
            if STATIC not in p.parents: return self.send_error(403)
            return self.send_file(p)
        if path.startswith("/workspace/"):
            p=(WORKSPACE/unquote(path[len("/workspace/"):])).resolve()
            if WORKSPACE not in p.parents and p!=WORKSPACE: return self.send_error(403)
            if p.is_dir(): return self.send_json({"folder":str(p)})
            return self.send_file(p)
        if path=="/api/status":
            engine_ok=False; detail=""
            try:
                # Importing Kokoro is the most useful real health check because Kokoro
                # configures Loguru in its package __init__.py. v0.2.0 launches this
                # server with real redirected stdout/stderr handles even though no
                # console window is shown.
                import kokoro; engine_ok=True; detail=f"Kokoro {getattr(kokoro,'__version__','installed')}"
            except Exception as e:
                detail=str(e)
                record_exception("Engine status check failed", e)
            return self.send_json({"version":APP_VERSION,"engine_ok":engine_ok,"engine_detail":detail,"engine_root":str(ENGINE_ROOT or ""),"workspace":str(WORKSPACE),"voices":VOICE_CATALOG,"project_count":len(list(PROJECTS.glob("*/project.json"))),"active_jobs":sum(1 for j in JOBS.values() if j.get('status')=='running'),"stdout_type":type(sys.stdout).__name__,"stderr_type":type(sys.stderr).__name__})
        if path=="/api/diagnostics": return self.send_json(engine_diagnostics())
        if path=="/api/projects":
            arr=[project_summary(x) for x in PROJECTS.glob("*/project.json")]; arr.sort(key=lambda x:x.get("updated_at",0),reverse=True); return self.send_json({"projects":arr})
        if path=="/api/actors": return self.send_json({"actors":actor_library()})
        if path=="/api/pronunciations": return self.send_json({"entries":pronunciation_entries()})
        if path=="/api/project":
            pid=(qs.get("id") or [""])[0]; p=project_dir(pid)/"project.json"; data=read_json(p)
            return self.send_json(data or {"error":"Project not found"},200 if data else 404)
        if path=="/api/job":
            jid=(qs.get("id") or [""])[0]; j=JOBS.get(jid); return self.send_json(j or {"error":"Job not found"},200 if j else 404)
        if path=="/api/sample": return self.send_json(sample_project())
        return self.send_error(404)
    def do_POST(self):
        global LAST_HEARTBEAT,HAD_HEARTBEAT
        u=urlparse(self.path); path=u.path
        try: data=self.body_json()
        except Exception as e: return self.send_json({"error":"Invalid JSON: "+str(e)},400)
        if path=="/api/heartbeat": LAST_HEARTBEAT=time.time(); HAD_HEARTBEAT=True; return self.send_json({"ok":True})
        if path=="/api/parse": return self.send_json(parse_script(data.get("script","")))
        if path=="/api/project/save":
            p=data.get("project",data); pid=ensure_project_id(p); parsed=parse_script(p.get("script","")); reconcile_actors(p,parsed["speakers"]); p["updated_at"]=time.time(); write_json(project_dir(pid)/"project.json",p); return self.send_json({"ok":True,"project":p})
        if path=="/api/project/delete":
            pid=data.get("id",""); p=project_dir(pid)
            if p.exists(): shutil.rmtree(p)
            return self.send_json({"ok":True})
        if path=="/api/upload":
            pid=data.get("project_id","") or f"p-{uuid.uuid4().hex[:12]}"; pdir=project_dir(pid); name=safe_name(data.get("filename","image.png"),"image.png"); raw=data.get("data","")
            if "," in raw: raw=raw.split(",",1)[1]
            blob=base64.b64decode(raw); ext=pathlib.Path(name).suffix.lower()
            if ext not in (".png",".jpg",".jpeg",".webp"): return self.send_json({"error":"Use PNG, JPG, JPEG, or WEBP images."},400)
            rel=pathlib.Path("assets")/(uuid.uuid4().hex[:8]+"-"+name); out=pdir/rel; out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(blob); return self.send_json({"ok":True,"project_id":pid,"path":str(rel).replace("\\","/"),"url":workspace_url(out)})
        if path=="/api/audition":
            try:
                text=str(data.get("text","The library will remain open until ten tonight.")).strip(); voice=str(data.get("voice","af_heart")); speed=float(data.get("speed",1.0)); pipelines=get_pipelines(); audio=render_text(prepare_speech_text(text),voice,speed,pipelines); out=WORKSPACE/"auditions"/f"audition-{voice}-{uuid.uuid4().hex[:8]}.mp3"; encode_mp3(audio,out); return self.send_json({"ok":True,"url":workspace_url(out)})
            except Exception as e:
                record_exception("Voice audition failed", e)
                return self.send_json({"error":str(e)},500)
        if path=="/api/line/render":
            try:
                p=data.get("project",{}); idx=int(data.get("line_index",0)); force=bool(data.get("force",False)); pid=ensure_project_id(p)
                parsed=parse_script(p.get("script","")); reconcile_actors(p,parsed["speakers"])
                if idx<0 or idx>=len(parsed["lines"]): return self.send_json({"error":"Line index is out of range."},400)
                line=parsed["lines"][idx]
                if line.get("kind")!="speech": return self.send_json({"error":"That row is a pause, not a spoken line."},400)
                actor=p["actors"].get(line["speaker"],default_actor(line["speaker"])); voice=actor.get("voice","af_heart")
                speed=float(line.get("speed",actor.get("speed",1.0))); synth_text=prepare_speech_text(line["text"]); key=cache_key(synth_text,voice,speed)
                pdir=project_dir(pid); audiodir=pdir/"cache"/"audio"; previewdir=pdir/"cache"/"previews"; audiodir.mkdir(parents=True,exist_ok=True); previewdir.mkdir(parents=True,exist_ok=True)
                wav=audiodir/f"{key}.wav"; was_cached=wav.exists() and not force
                if force or not wav.exists():
                    audio=render_text(synth_text,voice,speed,get_pipelines()); save_wav(audio,wav)
                else: audio=load_wav(wav)
                mp3=previewdir/f"line-{idx:04}-{key}.mp3"; encode_mp3(audio,mp3,kbps=int(p.get("settings",{}).get("mp3_kbps",128)))
                p["updated_at"]=time.time(); write_json(pdir/"project.json",p)
                return self.send_json({"ok":True,"project_id":pid,"url":workspace_url(mp3),"cached":was_cached,"voice":voice,"speed":speed,"pronunciation_applied":synth_text!=line["text"]})
            except Exception as e:
                record_exception("Line preview failed",e); return self.send_json({"error":str(e)},500)
        if path=="/api/actors/save":
            a=compact_actor(data.get("actor",data)); items=actor_library(); existing=next((i for i,x in enumerate(items) if x.get("id")==a["id"]),None)
            if existing is None: items.append(a)
            else: items[existing]=a
            write_json(ACTOR_LIBRARY_FILE,items); return self.send_json({"ok":True,"actor":a,"actors":items})
        if path=="/api/actors/delete":
            aid=str(data.get("id","")); items=[x for x in actor_library() if x.get("id")!=aid]; write_json(ACTOR_LIBRARY_FILE,items); return self.send_json({"ok":True,"actors":items})
        if path=="/api/pronunciations/save":
            e=data.get("entry",data); term=str(e.get("term","")).strip(); repl=str(e.get("replacement","")).strip()
            if not term or not repl: return self.send_json({"error":"Both Written text and Speak as are required."},400)
            item={"id":safe_name(e.get("id",""),"") or f"pron-{uuid.uuid4().hex[:10]}","term":term,"replacement":repl,"case_sensitive":bool(e.get("case_sensitive",False))}
            items=pronunciation_entries(); pos=next((i for i,x in enumerate(items) if x.get("id")==item["id"]),None)
            if pos is None: items.append(item)
            else: items[pos]=item
            write_json(PRONUNCIATION_FILE,items); return self.send_json({"ok":True,"entry":item,"entries":items})
        if path=="/api/pronunciations/delete":
            eid=str(data.get("id","")); items=[x for x in pronunciation_entries() if x.get("id")!=eid]; write_json(PRONUNCIATION_FILE,items); return self.send_json({"ok":True,"entries":items})
        if path=="/api/generate":
            project=data.get("project",{}); options=data.get("options",{}); jid=uuid.uuid4().hex; JOBS[jid]={"id":jid,"status":"running","stage":"Starting","current":0,"total":0,"message":"Preparing project","cancelled":False}; threading.Thread(target=render_project_job,args=(jid,project,options),daemon=True).start(); return self.send_json({"job_id":jid})
        if path=="/api/batch":
            rows=data.get("rows",[]); jid=uuid.uuid4().hex; JOBS[jid]={"id":jid,"status":"running","stage":"Starting batch","current":0,"total":len(rows),"message":"Preparing","cancelled":False}; threading.Thread(target=render_batch_job,args=(jid,rows),daemon=True).start(); return self.send_json({"job_id":jid})
        if path=="/api/job/cancel":
            jid=data.get("id","");
            if jid in JOBS: JOBS[jid]["cancelled"]=True
            return self.send_json({"ok":True})
        if path=="/api/maintenance":
            action=str(data.get("action","")).lower()
            try:
                if action=="open_engine":
                    if not ENGINE_ROOT: return self.send_json({"error":"No engine location is configured."},400)
                    open_local_path(ENGINE_ROOT); return self.send_json({"ok":True,"path":str(ENGINE_ROOT)})
                if action=="open_workspace":
                    WORKSPACE.mkdir(parents=True,exist_ok=True); open_local_path(WORKSPACE); return self.send_json({"ok":True,"path":str(WORKSPACE)})
                if action=="open_logs":
                    logs=WORKSPACE/"logs"; logs.mkdir(parents=True,exist_ok=True); open_local_path(logs); return self.send_json({"ok":True,"path":str(logs)})
                if action=="repair":
                    if os.name!="nt": return self.send_json({"error":"The bundled repair launcher is for Windows."},400)
                    script=HERE/"REPAIR_ENGINE.cmd"
                    if not script.exists(): return self.send_json({"error":"Repair script is missing."},500)
                    subprocess.Popen(["cmd.exe","/c",str(script)],cwd=str(HERE),creationflags=getattr(subprocess,"CREATE_NEW_CONSOLE",0))
                    return self.send_json({"ok":True,"message":"Repair window opened. Close ScriptCast before allowing package repair to run."})
                if action=="first_run":
                    if os.name!="nt": return self.send_json({"error":"The bundled setup launcher is for Windows."},400)
                    script=HERE/"FIRST_RUN_SETUP.cmd"
                    subprocess.Popen(["cmd.exe","/c",str(script)],cwd=str(HERE),creationflags=getattr(subprocess,"CREATE_NEW_CONSOLE",0))
                    return self.send_json({"ok":True,"message":"Setup window opened."})
                return self.send_json({"error":"Unknown maintenance action."},400)
            except Exception as e:
                record_exception("Maintenance action failed",e); return self.send_json({"error":str(e)},500)
        if path=="/api/open_folder":
            rel=data.get("project_id",""); target=project_dir(rel)/"renders" if rel else WORKSPACE; target.mkdir(parents=True,exist_ok=True)
            try: open_local_path(target)
            except Exception as e: return self.send_json({"error":str(e)},500)
            return self.send_json({"ok":True,"path":str(target)})
        return self.send_error(404)


def monitor_shutdown():
    global SERVER_REF
    while True:
        time.sleep(10)
        if not SERVER_REF: continue
        running=any(j.get("status")=="running" for j in JOBS.values())
        if HAD_HEARTBEAT and not running and time.time()-LAST_HEARTBEAT>45:
            try: SERVER_REF.shutdown()
            except: pass
            break


def self_test():
    p=parse_script("Alice: Hello.\nBob: Hi there.\n[pause 500]\n[Narrator speed=0.95 pause=700] Welcome.")
    assert p["speakers"]==["Alice","Bob","Narrator"] and len(p["lines"])==4
    sp=sample_project(); assert "Maya" in sp["actors"]
    a=compact_actor({"actor_name":"Test","accent":"British","gender":"Male","voice":"bm_george","speed":0.97,"pause_ms":420}); assert a["voice"]=="bm_george"
    print("ScriptCast self-test OK")
    print("Workspace:",WORKSPACE)
    print("Parsed lines:",len(p["lines"]),"Speakers:",p["speakers"])


def main():
    global SERVER_REF
    ap=argparse.ArgumentParser(); ap.add_argument("--port",type=int,default=8765); ap.add_argument("--self-test",action="store_true"); args=ap.parse_args()
    if args.self_test: return self_test()
    server=ThreadingHTTPServer(("127.0.0.1",args.port),Handler); SERVER_REF=server; threading.Thread(target=monitor_shutdown,daemon=True).start(); print(f"ScriptCast Studio {APP_VERSION} running at http://127.0.0.1:{args.port}"); server.serve_forever()

if __name__=="__main__": main()
